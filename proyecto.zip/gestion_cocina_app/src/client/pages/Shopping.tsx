import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faShoppingCart, faPlus, faTimes, faCircleNotch, faTrash, faSearch, faExclamationTriangle } from '@fortawesome/free-solid-svg-icons';
import toast from 'react-hot-toast';

import { ApiService } from '../services/ApiService';
import { BackButton } from '../components/shared/BackButton';
import { Product } from '../../server/schemas/productSchema';
import { Provider } from '../schemas/providerSchema';
import '../../css/shopping.css';

interface ProductWithProvider extends Product {
  provider: {
    id: number;
    name: string;
  } | null;
}

interface ProviderData {
  id: number;
  name: string;
  cuit: string | null;
  address: string | null;
}

interface PurchaseItem {
  id: string;
  productId: number;
  productName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
}

interface InventoryAlert extends Product {
  provider: {
    id: number;
    name: string;
  } | null;
}

export function Shopping() {
  const navigate = useNavigate();
  
  // Providers state
  const [providers, setProviders] = useState<ProviderData[]>([]);
  const [loadingProviders, setLoadingProviders] = useState<boolean>(true);
  const [selectedProviderId, setSelectedProviderId] = useState<number | null>(null);
  
  // Products state (for selector)
  const [products, setProducts] = useState<ProductWithProvider[]>([]);
  const [loadingProducts, setLoadingProducts] = useState<boolean>(false);
  
  // Purchase items state (invoice lines)
  const [purchaseItems, setPurchaseItems] = useState<PurchaseItem[]>([]);
  const [showProductSelector, setShowProductSelector] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  
  // Submit state
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  
  // Alerts state (stock below min)
  const [alerts, setAlerts] = useState<InventoryAlert[]>([]);
  const [loadingAlerts, setLoadingAlerts] = useState<boolean>(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoadingProviders(true);
    setLoadingAlerts(true);
    
    try {
      const [providersRes, alertsRes] = await Promise.all([
        ApiService.get<{ success: boolean; data: ProviderData[] }>('/api/providers?limit=1000'),
        ApiService.get<{ success: boolean; data: InventoryAlert[]; count: number }>('/api/inventory/alerts'),
      ]);
      
      if (providersRes.success) setProviders(providersRes.data);
      if (alertsRes.success) setAlerts(alertsRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoadingProviders(false);
      setLoadingAlerts(false);
    }
  };

  const fetchProductsForProvider = async (providerId: number) => {
    setLoadingProducts(true);
    try {
      const response = await ApiService.get<{ success: boolean; data: ProductWithProvider[] }>(`/api/products?limit=1000&providerId=${providerId}`);
      if (response.success) {
        setProducts(response.data);
      }
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoadingProducts(false);
    }
  };

  useEffect(() => {
    if (selectedProviderId) {
      fetchProductsForProvider(selectedProviderId);
    } else {
      setProducts([]);
    }
  }, [selectedProviderId]);

  const calculateTotal = () => {
    return purchaseItems.reduce((sum, item) => sum + item.subtotal, 0);
  };

  const handleAddProduct = (product: ProductWithProvider) => {
    const newItem: PurchaseItem = {
      id: `${product.id}-${Date.now()}`,
      productId: product.id,
      productName: product.name,
      quantity: 1,
      unitPrice: product.unitPrice || 0,
      subtotal: product.unitPrice || 0,
    };
    setPurchaseItems([...purchaseItems, newItem]);
    setShowProductSelector(false);
    setSearchTerm('');
  };

  const handleRemoveItem = (id: string) => {
    setPurchaseItems(purchaseItems.filter(item => item.id !== id));
  };

  const handleItemChange = (id: string, field: 'quantity' | 'unitPrice', value: number) => {
    setPurchaseItems(purchaseItems.map(item => {
      if (item.id === id) {
        const updated = { ...item, [field]: value };
        updated.subtotal = updated.quantity * updated.unitPrice;
        return updated;
      }
      return item;
    }));
  };

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
    !purchaseItems.some(item => item.productId === p.id)
  );

  const handleSubmit = async () => {
    if (!selectedProviderId) {
      toast.error('Seleccione un proveedor');
      return;
    }
    
    if (purchaseItems.length === 0) {
      toast.error('Agregue al menos un producto');
      return;
    }

    setIsSubmitting(true);

    try {
      const payload = {
        providerId: selectedProviderId,
        items: purchaseItems.map(item => ({
          productId: item.productId,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
        })),
        notes: notes || undefined,
      };

      const response = await ApiService.post('/api/purchases', payload);
      
      if (response.success) {
        toast.success('Compra registrada exitosamente');
        handleClear();
        await fetchData();
      } else {
        if (response.productNotFound) {
          const productName = response.productName || 'desconocido';
          if (window.confirm(`El producto "${productName}" no existe en el inventario. ¿Desea crearlo ahora?`)) {
            navigate('/products');
          }
        } else {
          toast.error(response.error || 'Error al registrar compra');
        }
      }
    } catch (error: any) {
      toast.error(error.message || 'Error al registrar compra');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClear = () => {
    setSelectedProviderId(null);
    setPurchaseItems([]);
    setNotes('');
  };

  const handleCancel = () => {
    navigate('/home');
  };

  if (loadingProviders || loadingProducts) {
    return (
      <div className="shopping-page">
        <div className="loading-indicator">
          <FontAwesomeIcon icon={faCircleNotch} spin size="lg" />
          Cargando...
        </div>
      </div>
    );
  }

  return (
    <div className="shopping-page">
      <header className="page-header">
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <BackButton />
          <h1><FontAwesomeIcon icon={faShoppingCart} /> Nueva Compra</h1>
        </div>
      </header>

      <div className="purchase-invoice">
        {/* Section 1: Provider Selection */}
        <div className="invoice-section">
          <h2>Seleccionar Proveedor</h2>
          <div className="provider-select-wrapper">
            <select
              value={selectedProviderId || ''}
              onChange={(e) => setSelectedProviderId(e.target.value ? Number(e.target.value) : null)}
              className="provider-select"
            >
              <option value="">Seleccione un proveedor...</option>
              {providers.map(provider => (
                <option key={provider.id} value={provider.id}>
                  {provider.name} {provider.cuit && `(${provider.cuit})`}
                </option>
              ))}
            </select>
          </div>
          {providers.length === 0 && (
            <div className="no-providers-notice">
              <p>No hay proveedores registrados.</p>
              <button 
                onClick={() => navigate('/providers')} 
                className="btn-primary"
              >
                <FontAwesomeIcon icon={faPlus} /> Nuevo Proveedor
              </button>
            </div>
          )}
        </div>

        {/* Section 2: Invoice Items */}
        {selectedProviderId && (
          <div className="invoice-section">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h2>Productos</h2>
              <button 
                onClick={() => setShowProductSelector(true)}
                className="btn-primary"
                disabled={products.length === 0}
              >
                <FontAwesomeIcon icon={faPlus} /> Agregar
              </button>
            </div>

            {purchaseItems.length === 0 ? (
              <div className="empty-message">
                Agregue productos a la factura. Haga clic en "Agregar".
              </div>
            ) : (
              <div className="invoice-items-table">
                <table>
                  <thead>
                    <tr>
                      <th>Producto</th>
                      <th>Cantidad</th>
                      <th>Precio Unit.</th>
                      <th>Subtotal</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {purchaseItems.map(item => (
                      <tr key={item.id}>
                        <td>{item.productName}</td>
                        <td>
                          <input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => handleItemChange(item.id, 'quantity', parseInt(e.target.value) || 1)}
                            className="qty-input"
                          />
                        </td>
                        <td>
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            value={item.unitPrice}
                            onChange={(e) => handleItemChange(item.id, 'unitPrice', parseFloat(e.target.value) || 0)}
                            className="price-input"
                          />
                        </td>
                        <td className="subtotal-cell">
                          ${item.subtotal.toFixed(2)}
                        </td>
                        <td>
                          <button 
                            onClick={() => handleRemoveItem(item.id)}
                            className="btn-remove-item"
                          >
                            <FontAwesomeIcon icon={faTrash} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr>
                      <td colSpan={3} className="total-label">Total</td>
                      <td colSpan={2} className="total-value">
                        ${calculateTotal().toFixed(2)}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            )}

            {/* Notes field */}
            <div className="notes-field">
              <label>Observaciones (opcional)</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Notas sobre la compra..."
                rows={2}
              />
            </div>
          </div>
        )}

        {/* Section 3: Actions */}
        {selectedProviderId && purchaseItems.length > 0 && (
          <div className="invoice-actions">
            <button onClick={handleClear} className="btn-secondary">
              Cancelar
            </button>
            <button 
              onClick={handleSubmit}
              className="btn-primary btn-confirm"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <FontAwesomeIcon icon={faCircleNotch} spin />
              ) : (
                <>
                  <FontAwesomeIcon icon={faShoppingCart} /> Confirmar Compra
                </>
              )}
            </button>
          </div>
        )}
      </div>

      {/* Section 4: Stock Alerts */}
      <div className="alerts-section">
        <h2>
          <FontAwesomeIcon icon={faExclamationTriangle} /> Productos bajo stock mínimo
        </h2>
        
        {loadingAlerts ? (
          <div className="loading-indicator">
            <FontAwesomeIcon icon={faCircleNotch} spin size="lg" />
            Cargando...
          </div>
        ) : alerts.length === 0 ? (
          <div className="no-alerts">
            No hay productos bajo stock mínimo.
          </div>
        ) : (
          <div className="alerts-table-container">
            <table className="alerts-table">
              <thead>
                <tr>
                  <th>Producto</th>
                  <th>Stock</th>
                  <th>Mín</th>
                  <th>Faltan</th>
                </tr>
              </thead>
              <tbody>
                {alerts.map(alert => (
                  <tr key={alert.id}>
                    <td>{alert.name}</td>
                    <td>{alert.quantity}</td>
                    <td>{alert.minStock}</td>
                    <td className="missing">{alert.minStock - alert.quantity}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Product Selector Modal */}
      {showProductSelector && (
        <div className="modal-overlay" onClick={() => setShowProductSelector(false)}>
          <div className="modal-content product-selector-modal" onClick={(e) => e.stopPropagation()}>
            <h2>Buscar Producto</h2>
            
            <div className="search-input-wrapper">
              <FontAwesomeIcon icon={faSearch} className="search-icon" />
              <input
                type="text"
                placeholder="Buscar producto..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                autoFocus
              />
            </div>

            <div className="product-list">
              {filteredProducts.length === 0 ? (
                <div className="empty-message">No hay productos disponibles</div>
              ) : (
                filteredProducts.map((product) => (
                  <div 
                    key={product.id} 
                    className="product-item"
                    onClick={() => handleAddProduct(product)}
                  >
                    <div className="product-info">
                      <span className="product-name">{product.name}</span>
                      <span className="product-provider">{product.provider?.name || 'Sin proveedor'}</span>
                    </div>
                    <div className="product-stock">
                      <span className="stock-value">{product.quantity} {product.unit}</span>
                    </div>
                  </div>
                ))
              )}
            </div>

            <button onClick={() => setShowProductSelector(false)} className="btn-close-modal">
              Cerrar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}