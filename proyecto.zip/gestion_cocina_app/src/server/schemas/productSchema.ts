import { z } from "zod";

export const ProductSchema = z.object({
  providerId: z.number().int().positive("El proveedor es obligatorio"),
  name: z.string().min(2, "El nombre del producto debe tener al menos 2 caracteres"),
  description: z.string().optional().or(z.literal("")),
  quantity: z.number().int().min(0, "La cantidad no puede ser negativa"),
  unit: z.string().min(1, "La unidad es obligatoria"),
  minStock: z.number().int().min(0).optional().default(0),
});

export type ProductInput = z.infer<typeof ProductSchema>;
