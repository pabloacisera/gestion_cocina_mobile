import { Router } from "express";
import { prisma } from "../prisma";
import { z } from "zod";

const router = Router();

const PurchaseItemSchema = z.object({
  productId: z.number().int().positive(),
  quantity: z.number().int().positive(),
  unitPrice: z.number().nonnegative(),
});

const PurchaseSchema = z.object({
  providerId: z.number().int().positive(),
  items: z.array(PurchaseItemSchema).min(1),
  notes: z.string().optional(),
});

interface PurchaseItem {
  productId: number;
  quantity: number;
  unitPrice: number;
}

interface PurchaseData {
  providerId: number;
  items: PurchaseItem[];
  notes?: string;
}

// GET /api/purchases
router.get("/", async (req, res, next) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const skip = (page - 1) * limit;

    const [purchases, total] = await Promise.all([
      prisma.purchase.findMany({
        skip,
        take: limit,
        include: {
          provider: true,
          items: {
            include: {
              product: true,
            },
          },
        },
        orderBy: {
          createdAt: 'desc',
        },
      }),
      prisma.purchase.count()
    ]);

    res.json({ 
      success: true, 
      data: purchases,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    next(error);
  }
});

// POST /api/purchases
router.post("/", async (req, res, next) => {
  try {
    const validated = PurchaseSchema.safeParse(req.body);
    if (!validated.success) {
      return res.status(400).json({
        success: false,
        error: "Validation failed",
        errors: validated.error.flatten(),
      });
    }

    const { providerId, items, notes } = validated.data as PurchaseData;

    // Verify provider exists
    const provider = await prisma.provider.findUnique({
      where: { id: providerId },
    });
    if (!provider) {
      return res.status(404).json({
        success: false,
        error: "Proveedor no encontrado",
      });
    }

    // Verify all products exist
    const productIds = items.map((item) => item.productId);
    const products = await prisma.product.findMany({
      where: { id: { in: productIds } },
      select: { id: true, name: true },
    });

    if (products.length !== items.length) {
      const foundIds = products.map((p) => p.id);
      const missingItem = items.find((item) => !foundIds.includes(item.productId));
      if (missingItem) {
        const missingProduct = await prisma.product.findUnique({
          where: { id: missingItem.productId },
        });
        return res.status(404).json({
          success: false,
          productNotFound: true,
          productName: missingProduct?.name || `ID: ${missingItem.productId}`,
        });
      }
    }

    // Calculate total amount
    const totalAmount = items.reduce((sum, item) => {
      return sum + item.quantity * item.unitPrice;
    }, 0);

    // Use transaction to create purchase, items, and stock movements
    const purchase = await prisma.$transaction(async (tx) => {
      // 1. Create the purchase
      const createdPurchase = await tx.purchase.create({
        data: {
          providerId,
          totalAmount,
          notes: notes || null,
        },
      });

      // 2. Create purchase items and stock movements
      const purchaseItems = [];
      const stockMovements = [];

      for (const item of items) {
        // Create purchase item
        const purchaseItem = await tx.purchaseItem.create({
          data: {
            purchaseId: createdPurchase.id,
            productId: item.productId,
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            subtotal: item.quantity * item.unitPrice,
          },
        });
        purchaseItems.push(purchaseItem);

        // Create stock movement (IN)
        const stockMovement = await tx.stockMovement.create({
          data: {
            productId: item.productId,
            quantity: item.quantity,
            type: "IN",
            reason: `Compra #${createdPurchase.id} - Proveedor: ${provider.name}`,
          },
        });
        stockMovements.push(stockMovement);

        // Increment product quantity and update unit price
        await tx.product.update({
          where: { id: item.productId },
          data: {
            quantity: {
              increment: item.quantity,
            },
            unitPrice: item.unitPrice,
          },
        });
      }

      // Return purchase with all related data
      return await tx.purchase.findUnique({
        where: { id: createdPurchase.id },
        include: {
          provider: true,
          items: {
            include: {
              product: true,
            },
          },
        },
      });
    });

    res.json({ success: true, data: purchase });
  } catch (error: any) {
    console.error("Error creating purchase:", error);
    next(error);
  }
});

export default router;
